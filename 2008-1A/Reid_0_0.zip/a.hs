import Control.Applicative
import Control.Monad
import Data.List

main = (enumFromTo 1 <$> readLn) >>= mapM_ (\caseno -> do
                                               getLine
                                               x <- map read . words <$> getLine
                                               y <- map read . words <$> getLine
                                               let answer = sum $ zipWith (*) (sort x) (reverse $ sort y)
                                               putStrLn $ "Case #" ++ show caseno ++ ": " ++ show answer
                                           )
       